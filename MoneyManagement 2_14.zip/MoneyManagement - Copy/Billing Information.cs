﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//Code
namespace MoneyManagement
{
    public partial class BillingInformation : Form
    {
        DataTable billingInformation = new DataTable();
        public BillingInformation()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        //When the New Button is clicked, it removes anny text from the fields
        private void NewButton_Click(object sender, EventArgs e)
        {
            invoiceDateTextBox.Text = "";
            vendorTextBox.Text = "";
            priceTextBox.Text = "";
            descriptionTextBox.Text = "";
            dueDateTextBox.Text = "";
            categoryBox.SelectedIndex = -1;
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            // Save all the values from our fields into variables
            String invoice_date = invoiceDateTextBox.Text;
            String vendor = vendorTextBox.Text;
            String price = priceTextBox.Text;   
            String description = descriptionTextBox.Text;
            String due_date = dueDateTextBox.Text;
            String category = (string)categoryBox.SelectedItem;
        
            // Add these values to the datatable
            billingInformation.Rows.Add(invoice_date, vendor, price, description, due_date, category);

            // Clear fields after saves
            NewButton_Click(sender, e);
        }

        //When the Delete Button is clicked, the selected row will be deleated
        private void DeleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                billingInformation.Rows[BillingInformationGrid.CurrentCell.RowIndex].Delete();
            }
            catch (Exception err)
            {
                Console.WriteLine("Error:   " + err);
            }

        }

        //Takes the variables that were saved and shows them in the grid
        private void BillingInformationGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                invoiceDateTextBox.Text = billingInformation.Rows[BillingInformationGrid.CurrentCell.RowIndex].ItemArray[0].ToString();
                vendorTextBox.Text = billingInformation.Rows[BillingInformationGrid.CurrentCell.RowIndex].ItemArray[1].ToString();
                priceTextBox.Text = billingInformation.Rows[BillingInformationGrid.CurrentCell.RowIndex].ItemArray[2].ToString();
                descriptionTextBox.Text = billingInformation.Rows[BillingInformationGrid.CurrentCell.RowIndex].ItemArray[3].ToString();
                dueDateTextBox.Text = billingInformation.Rows[BillingInformationGrid.CurrentCell.RowIndex].ItemArray[4].ToString();

                String itemToLookFor = billingInformation.Rows[BillingInformationGrid.CurrentCell.RowIndex].ItemArray[5].ToString();
                categoryBox.SelectedIndex = categoryBox.Items.IndexOf(itemToLookFor);
            }
            catch(Exception err)
            {
                //Creates an error if something goes wrong
                Console.WriteLine("There has been an error: " + err);
            }
        }
        
        private void BillingInformationGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //Creates the columns for the grid
        private void BillingInformation_Load(object sender, EventArgs e)
        {
            billingInformation.Columns.Add("Invoice Date");
            billingInformation.Columns.Add("Vendor Name");
            billingInformation.Columns.Add("Price");
            billingInformation.Columns.Add("Description");
            billingInformation.Columns.Add("Due Date");
            billingInformation.Columns.Add("Category");

            BillingInformationGrid.DataSource = billingInformation;
        }

        private void categoryTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void QuantityLabel_Click(object sender, EventArgs e)
        {

        }

        private void categoryBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void skuTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
